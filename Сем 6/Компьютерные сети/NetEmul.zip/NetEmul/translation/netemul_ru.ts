<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU" sourcelanguage="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="221"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="229"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="232"/>
        <source>Ctrl+Alt+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <source>Ctrl+Alt+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="149"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <source>You want to go?</source>
        <translation type="obsolete">Вы хотите выйти ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="144"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="144"/>
        <source>Create new network</source>
        <translation>Создать новую сеть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <source>Packet designer...</source>
        <translation>Конструктор пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="577"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="145"/>
        <source>Open existing file</source>
        <translation>Открыть существующую сеть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="145"/>
        <source>Open...</source>
        <translation>Открыть...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="146"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="146"/>
        <source>Save network</source>
        <translation>Сохранить сеть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="147"/>
        <source>Save as...</source>
        <translation>Сохранить как...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="147"/>
        <source>Save network as...</source>
        <translation>Сохранить сеть как ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>Close current file</source>
        <translation>Закрыть текущий файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="150"/>
        <source>Show grid</source>
        <translation>Показывать сетку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Deleting object</source>
        <translation>Удалить объект</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="153"/>
        <source>Programs</source>
        <translation>Программы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="153"/>
        <source>Programs installed on device</source>
        <translation>Установленные программы</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation type="obsolete">Настройки</translation>
    </message>
    <message>
        <source>Setting...</source>
        <translation type="obsolete">Настройки...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="156"/>
        <source>Statistics </source>
        <translation>Статистика</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="156"/>
        <source>Show scene statistics </source>
        <translation>Показать статистику сцены</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="157"/>
        <source>Move</source>
        <translation>Перемещение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="157"/>
        <source>Move objects</source>
        <translation>Перемещение объектов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="159"/>
        <source>Cable</source>
        <translation>Кабель</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="159"/>
        <source>Create connection</source>
        <translation>Создать соединение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>Note</source>
        <translation>Записки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>Insert text comment</source>
        <translation>Вставить текстовую надпись</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Unibus</source>
        <translation>Общая шина</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Add unibus</source>
        <translation>Добавить общую шину</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <source>Computer</source>
        <translation>Компьютер</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <source>Add computer</source>
        <translation>Добавить Компьютер</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="165"/>
        <source>Hub</source>
        <translation>Концентратор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="165"/>
        <source>Add hub</source>
        <translation>Добавить Концентратор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="166"/>
        <source>Switch</source>
        <translation>Коммутатор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="166"/>
        <source>Add switch</source>
        <translation>Добавить Коммутатор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="167"/>
        <source>Router</source>
        <translation>Маршрутизатор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="167"/>
        <source>Add router</source>
        <translation>Добавить Маршрутизатор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="168"/>
        <source>Send</source>
        <translation>Отправка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="168"/>
        <source>Send data</source>
        <translation>Отправить данные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <source>Execute scripts</source>
        <translation>Выполнить  сценарий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <source>Run existing scripts</source>
        <translation>Запустить готовые сценарии</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <source>Show properties</source>
        <translation>Показать свойства</translation>
    </message>
    <message>
        <source>Packet desinger</source>
        <translation type="obsolete">Конструктор пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <source>Create user&apos;s packet</source>
        <translation>Создать пользовательский пакет</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="181"/>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="309"/>
        <source>Ctrl+F1</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;h2&gt;NetEmul 0.8.5&lt;/h2&gt;&lt;p&gt;NetEmul is a program for the simulation of the computer network.</source>
        <translation type="obsolete">&lt;h2&gt;NetEmul 0.8.5&lt;/h2&gt;&lt;p&gt;NetEmul программа для симуляции работы компьютерной сети.</translation>
    </message>
    <message>
        <source>Routing Table</source>
        <translation type="obsolete">Таблица маршрутизации</translation>
    </message>
    <message>
        <source>Edit routing table</source>
        <translation type="obsolete">Редактировать таблицу маршрутизации</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="281"/>
        <source>Ctrl+T</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="170"/>
        <source>About Qt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="126"/>
        <source>File was modified</source>
        <translation>Файл был изменен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="126"/>
        <source>File was modified, do you want to save changes?</source>
        <translation>Файл был изменен, вы хотите сохранить изменения?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="164"/>
        <source>About NetEmul</source>
        <translation>О программе NetEmul</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>NetEmul Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>Full help system program</source>
        <translation>Полная справка о программе</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="158"/>
        <source>Netcards</source>
        <translation>Интерфейсы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="158"/>
        <source>Edit netcards</source>
        <translation>Редактировать интерфейсы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <location filename="../src/mainwindow.cpp" line="695"/>
        <source>Stop</source>
        <translation>Остановить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <location filename="../src/mainwindow.cpp" line="696"/>
        <source>Stop simulation</source>
        <translation>Остановить симуляцию</translation>
    </message>
    <message>
        <source>Programms</source>
        <translation type="obsolete">Программы</translation>
    </message>
    <message>
        <source>Programms installed on device</source>
        <translation type="obsolete">Программы установленные на устройстве</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <source>Arp table</source>
        <translation>Arp таблица</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="154"/>
        <source>Settings...</source>
        <translation>Настройки...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="154"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="172"/>
        <source>Show log</source>
        <translation>Показать журнал</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="172"/>
        <source>Show device log file</source>
        <translation>Показать журнал устройства</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <source>About device</source>
        <translation>Об устройстве</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <source>Information about device</source>
        <translation>Информация об устройстве</translation>
    </message>
    <message>
        <source>Packet desinger...</source>
        <translation type="obsolete">Конструктор пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Print...</source>
        <translation>Печать...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Print user&apos;s network</source>
        <translation>Напечать пользовательскую сеть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Preview...</source>
        <translation>Предпросмотр...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Preview network berfore printing</source>
        <translation>Предпросмотр сети перед печатью</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>Configure VLAN...</source>
        <translation>Настройка VLAN...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>Configure VLAN</source>
        <translation>Настройка VLAN</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>Set description...</source>
        <translation>Задать описание...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>Set description of device</source>
        <translation>Задать описание для устройства</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Show labels</source>
        <translation>Показывать надписи</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Show labels on cables</source>
        <translation>Показывать надписи на проводах</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="183"/>
        <source>Object</source>
        <translation>Объект</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <source>Service</source>
        <translation>Сервис</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Scripts</source>
        <translation>Скрипты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="187"/>
        <source>Devices</source>
        <translation>Устройства</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Controls</source>
        <translation>Управление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="241"/>
        <source>Ctrl+1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="245"/>
        <source>Ctrl+2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <source>Ctrl+3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>Ctrl+4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="260"/>
        <source>Ctrl+5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="264"/>
        <source>Ctrl+6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="268"/>
        <source>Ctrl+7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <source>Ctrl+8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="306"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Log</source>
        <translation type="obsolete">Log</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Save file as ...</source>
        <translation>Сохранить файл как...</translation>
    </message>
    <message>
        <source>Networks(*.net)</source>
        <translation type="obsolete">Сети(*.net)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="690"/>
        <source>Play</source>
        <translation>Запустить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Start simulation</source>
        <translation>Запустить симуляцию</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="294"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <source>Do you really want to exit the program?</source>
        <translation type="obsolete">Вы действительно хотите выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="300"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="303"/>
        <source>Ctrl+Shift+A</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/chips/boxchip.cpp" line="42"/>
        <location filename="../src/chips/boxchip.cpp" line="68"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="189"/>
        <location filename="../src/packets/udppacket.cpp" line="38"/>
        <source>RIP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="190"/>
        <source>Connected</source>
        <translation>Подключена</translation>
    </message>
    <message>
        <location filename="../src/models/arpmodel.h" line="54"/>
        <location filename="../src/models/routemodel.cpp" line="188"/>
        <location filename="../src/models/switchmodel.h" line="34"/>
        <source>Static</source>
        <translation>Статическая</translation>
    </message>
    <message>
        <location filename="../src/models/arpmodel.h" line="55"/>
        <location filename="../src/models/switchmodel.h" line="35"/>
        <source>Dinamic</source>
        <translation>Динамическая</translation>
    </message>
    <message>
        <source>Receive frames: %1
</source>
        <translation type="obsolete">Получено кадров: %1
</translation>
    </message>
    <message>
        <source>Receive packets: %1
</source>
        <translation type="obsolete">Получено пакетов: %1
</translation>
    </message>
    <message>
        <source>Send frames: %1
</source>
        <translation type="obsolete">Отправлено кадров: %1
</translation>
    </message>
    <message>
        <source>Send packets: %1
</source>
        <translation type="obsolete">Отправлено пакетов: %1
</translation>
    </message>
    <message>
        <location filename="../src/chips/interface.cpp" line="108"/>
        <location filename="../src/devices/smartdevice.cpp" line="101"/>
        <location filename="../src/devices/smartdevice.cpp" line="247"/>
        <source>The network is not working correctly</source>
        <translation>Сеть работает не корректно</translation>
    </message>
    <message>
        <location filename="../src/chips/interface.cpp" line="109"/>
        <source>The network found a matching IP address</source>
        <translation>В сети обнаружено совпадение IP адресов</translation>
    </message>
    <message>
        <source>The network found a match ip-address! </source>
        <translation type="obsolete">В сети обнаружены совпадающие ip адреса!</translation>
    </message>
    <message>
        <location filename="../src/tools/statistics.cpp" line="71"/>
        <source>Received frames: %1
</source>
        <translation>Получено кадров: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statistics.cpp" line="72"/>
        <source>Received packets: %1
</source>
        <translation>Получено пакетов: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statistics.cpp" line="73"/>
        <source>Sent frames: %1
</source>
        <translation>Отправлено кадров: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statistics.cpp" line="74"/>
        <source>Sent packets: %1
</source>
        <translation>Отправлено пакетов: %1
</translation>
    </message>
    <message>
        <location filename="../src/frame.cpp" line="37"/>
        <source>Ethernet, sender: %1 receiver: %2</source>
        <translation>Ethernet, отправитель: %1 получатель: %2</translation>
    </message>
    <message>
        <source>IP packet, sender: %1, receiver: %2</source>
        <translation type="obsolete">IP пакет, отправитель: %1, получатель: %2</translation>
    </message>
    <message>
        <location filename="../src/packets/udppacket.cpp" line="37"/>
        <source>UDP Message user</source>
        <translation>UDP сообщение пользователя</translation>
    </message>
    <message>
        <location filename="../src/packets/udppacket.cpp" line="39"/>
        <source>DHCP message</source>
        <translation>DHCP сообщение</translation>
    </message>
    <message>
        <location filename="../src/packets/udppacket.cpp" line="40"/>
        <source>None</source>
        <translation>Неопределенно</translation>
    </message>
    <message>
        <location filename="../src/packets/tcppacket.cpp" line="45"/>
        <location filename="../src/packets/udppacket.cpp" line="47"/>
        <source>sender port: %1, receiver port: %2</source>
        <translation>порт отправителя: %1, порт получателя: %2</translation>
    </message>
    <message>
        <location filename="../src/commands/addcommand.cpp" line="48"/>
        <source>Add %1</source>
        <translation>Добавить %1</translation>
    </message>
    <message>
        <location filename="../src/commands/deletecommand.cpp" line="38"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/commands/movecommand.cpp" line="27"/>
        <source>Move</source>
        <translation>Перемещение</translation>
    </message>
    <message>
        <location filename="../src/states/sendstate.cpp" line="58"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/states/sendstate.cpp" line="58"/>
        <source>The device can&apos;t transmit data!</source>
        <translation>Устройство не может отправлять данные!</translation>
    </message>
    <message>
        <location filename="../src/commands/addcablecommand.cpp" line="28"/>
        <source>Add cable</source>
        <translation>Добавить кабель</translation>
    </message>
    <message>
        <location filename="../src/commands/addtextcommand.cpp" line="28"/>
        <source>Add note</source>
        <translation>Добавить комментарий</translation>
    </message>
    <message>
        <location filename="../src/packets/ippacket.cpp" line="56"/>
        <source>IP packet, sender: %1, receiver: %2 TTL: %3</source>
        <translation>IP пакет, отправитель: %1, получатель: %2 TTL %3</translation>
    </message>
    <message>
        <location filename="../src/devices/smartdevice.cpp" line="102"/>
        <source>Can&apos;t route packet! See adapter settings!</source>
        <translation>Невозможно маршрутизировать пакет! Проверьте настройки!</translation>
    </message>
    <message>
        <location filename="../src/devices/smartdevice.cpp" line="248"/>
        <source>Can&apos;t set this gateway! See adapter settings!</source>
        <translation>Невозможнов выставить шлюз! Проверьте настройки адаптеров!</translation>
    </message>
    <message>
        <location filename="../src/tools/scenexmlreader.cpp" line="22"/>
        <source>The file is not a NetEmul file.</source>
        <translation>Этот файл не является файлом NetEmul.</translation>
    </message>
</context>
<context>
    <name>aboutWindow</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Настройки</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="14"/>
        <source>About program</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="37"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="43"/>
        <source>Program for simulating computer networks.

(C) 2009 Semenov Pavel and Omilaeva Anastasia

</source>
        <translation>Программа для симуляции компьютерной сети.

(C) 2009 Семенов Павел и Омилаева Анастасия

</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="55"/>
        <source>Authors</source>
        <translation>Авторы</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="61"/>
        <source>&lt;a href=&quot;https://sourceforge.net/projects/netemul&quot;&gt;Home Page&lt;/a&gt;&lt;br&gt;&lt;br&gt;
Semenov Pavel - Project admin. Developer.&lt;br&gt;
&lt;br&gt;
Omilaeva Anastasia - Developer.</source>
        <translation>&lt;a href=&quot;https://sourceforge.net/projects/netemul&quot;&gt;Домашняя страница&lt;/a&gt;&lt;br&gt;&lt;br&gt;
Семенов павел - Администратор проекта, Разработчик.&lt;br&gt;
&lt;br&gt;
Омилаева Анастасия - Разработчик.</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="72"/>
        <source>Thanks to</source>
        <translation>Благодарности</translation>
    </message>
    <message utf8="true">
        <location filename="../src/forms/aboutwindow.ui" line="78"/>
        <source>Konstantin Andreev - Author of the idea and creator of the icons, 
Arina Shelest - Author of the logotype.

Lisandro Damián Nicanor Pérez Meyer
Márcio Moraes</source>
        <translation>Константин Андреев - автор идеи проекта, автор иконок, 
Арина Шелест - автор логотипа программы.

Lisandro Damián Nicanor Pérez Meyer
Márcio Moraes</translation>
    </message>
    <message>
        <source>Konstantin Andreev - Author of the idea and creator of the icons, 

Lisandro Damián Nicanor Pérez Meyer
Márcio Moraes</source>
        <translation type="obsolete">Константин Андреев - Автор идеи проекта и создатель иконок, 

Lisandro Damián Nicanor Pérez Meyer
Márcio Moraes</translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="90"/>
        <source>Translation</source>
        <translation>Перевод</translation>
    </message>
    <message utf8="true">
        <location filename="../src/forms/aboutwindow.ui" line="96"/>
        <source>Семенов Павел - Русский
Márcio Moraes - Português brasileiro
Lisandro Damián Nicanor Pérez Meyer - Español</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/aboutwindow.ui" line="124"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>adapterProperty</name>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="34"/>
        <source>Netcard</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="45"/>
        <source>Netcard name: </source>
        <translation>Имя адаптера:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="55"/>
        <source>Mac-address: </source>
        <translation>Мас-адрес: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="64"/>
        <source>Ip-address: </source>
        <translation>Ip-адрес: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="68"/>
        <source>Mask: </source>
        <translation>Маска:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="79"/>
        <source>Receive settings automatically</source>
        <translation>Получать настройки автоматически</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="85"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="86"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="92"/>
        <source>Reset statistics</source>
        <translation>Сбросить статистику</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="182"/>
        <location filename="../src/dialogs/adapterproperty.cpp" line="189"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="183"/>
        <source>First, remove the cable!</source>
        <translation>Сначала извлеките кабель!</translation>
    </message>
    <message>
        <location filename="../src/dialogs/adapterproperty.cpp" line="189"/>
        <source>At least a netcard must exist</source>
        <translation>Должен быть хотя бы один адаптер</translation>
    </message>
    <message>
        <source>Must be at least one netcard</source>
        <translation type="obsolete">Должен остаться хотя бы один адаптер</translation>
    </message>
</context>
<context>
    <name>boxChip</name>
    <message>
        <location filename="../src/chips/boxchip.cpp" line="137"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>computer</name>
    <message>
        <location filename="../src/devices/computer.cpp" line="36"/>
        <source>eth%1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/devices/computer.cpp" line="38"/>
        <source>&lt;b&gt;Computer&lt;/b&gt;&lt;!--You can use HTML.--&gt;</source>
        <translation>&lt;b&gt;Компьютер&lt;/b&gt;&lt;!--Вы можете использовать HTML.--&gt;</translation>
    </message>
    <message>
        <location filename="../src/devices/computer.h" line="45"/>
        <source>Computer</source>
        <translation>Компьютер</translation>
    </message>
</context>
<context>
    <name>computerProperty</name>
    <message>
        <source>Proreties</source>
        <translation type="obsolete">Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/computerproperty.cpp" line="28"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/computerproperty.cpp" line="32"/>
        <source>Default gateway:</source>
        <translation>Шлюз по умолчанию: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/computerproperty.cpp" line="36"/>
        <source>Enable routing</source>
        <translation>Включить маршрутизацию</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete">Описание:</translation>
    </message>
</context>
<context>
    <name>connectDilog</name>
    <message>
        <location filename="../src/forms/connectdialog.ui" line="14"/>
        <source>Specify the initial preferences </source>
        <translation>Укажите начальные настройки</translation>
    </message>
    <message>
        <location filename="../src/forms/connectdialog.ui" line="20"/>
        <source>Select the connected interfaces: </source>
        <translation>Выберите соединяемые интерфейсы:</translation>
    </message>
    <message>
        <location filename="../src/forms/connectdialog.ui" line="45"/>
        <source>Connect</source>
        <translation>Соединить</translation>
    </message>
    <message>
        <location filename="../src/forms/connectdialog.ui" line="56"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>designerDialog</name>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="41"/>
        <source>Main</source>
        <translation>Основное</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="42"/>
        <source>Frame</source>
        <translation>Кадр</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="43"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="109"/>
        <source>Ip</source>
        <translation>Ip</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="44"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="110"/>
        <source>Arp</source>
        <translation>Arp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="45"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="132"/>
        <source>Tcp</source>
        <translation>Tcp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="46"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="133"/>
        <source>Udp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="52"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="53"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="61"/>
        <source>Packet designer</source>
        <translation>Конструктор пакетов</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="68"/>
        <source>Choose interface: </source>
        <translation>Укажите интерфейс:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="78"/>
        <source>Count: </source>
        <translation>Количество:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="94"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="158"/>
        <source>Sender mac: </source>
        <translation>Mac отправителя:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="101"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="165"/>
        <source>Receiver mac: </source>
        <translation>Mac получателя:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="126"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="171"/>
        <source>Sender ip: </source>
        <translation>Ip отправителя:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="127"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="172"/>
        <source>Receiver ip: </source>
        <translation>Ip получателя: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="151"/>
        <source>Response</source>
        <translation>Ответ</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="152"/>
        <source>Request</source>
        <translation>Запрос</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="185"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="232"/>
        <source>Sender port: </source>
        <translation>Порт отправителя: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="190"/>
        <location filename="../src/dialogs/designerdialog.cpp" line="238"/>
        <source>Receiver port: </source>
        <translation>Порт получателя: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="197"/>
        <source>Sequence number: </source>
        <translation>Последовательный номер: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="202"/>
        <source>Ack number: </source>
        <translation>Подтвержденый номер: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="209"/>
        <source>Flags</source>
        <translation>Флаги</translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="211"/>
        <source>SYN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="212"/>
        <source>ACK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="216"/>
        <source>RST</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/designerdialog.cpp" line="217"/>
        <source>FIN</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>deviceNoteDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Настройки</translation>
    </message>
    <message>
        <location filename="../src/forms/devicenotedialog.ui" line="14"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../src/forms/devicenotedialog.ui" line="20"/>
        <source>Description:</source>
        <translation>Описание:</translation>
    </message>
    <message>
        <location filename="../src/forms/devicenotedialog.ui" line="49"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/forms/devicenotedialog.ui" line="60"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>dhcpClientProgramm</name>
    <message>
        <location filename="../src/programms/dhcpclientprogramm.cpp" line="28"/>
        <source>DHCP client</source>
        <translation>DHCP клиент</translation>
    </message>
</context>
<context>
    <name>dhcpClientProperty</name>
    <message>
        <location filename="../src/forms/dhcpclientproperty.ui" line="14"/>
        <source>DHCP client property</source>
        <translation>Свойства DHCP-клиента</translation>
    </message>
    <message>
        <source>Choose interfaces which must be under DHCP control: </source>
        <translation type="obsolete">Выберите интерфейсы, которые должны быть под контролем DHCP:</translation>
    </message>
    <message>
        <source>Choose interfaces which must be
 under DHCP control: </source>
        <translation type="obsolete">Укажите интерфейсы которые должны находиться под контролем DHCP:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpclientproperty.ui" line="20"/>
        <source>Choose interfaces which must&lt;br&gt; be under DHCP control: </source>
        <translation>Укажите интерфейсы, &lt;br&gt; контролируемые DHCP:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpclientproperty.ui" line="32"/>
        <source>Waiting time for offers&lt;br&gt; from dhcp-server</source>
        <translation>Время ожидания &lt;br&gt;предложения dhcp-сервера</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpclientproperty.ui" line="75"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpclientproperty.ui" line="86"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>dhcpServerModel</name>
    <message>
        <location filename="../src/models/dhcpservermodel.cpp" line="45"/>
        <source>Mac-address</source>
        <translation>Мас-адрес</translation>
    </message>
    <message>
        <location filename="../src/models/dhcpservermodel.cpp" line="46"/>
        <source>Ip-address</source>
        <translation>Ip-адрес</translation>
    </message>
    <message>
        <location filename="../src/models/dhcpservermodel.cpp" line="47"/>
        <source>Mask</source>
        <translation>Маска</translation>
    </message>
    <message>
        <location filename="../src/models/dhcpservermodel.cpp" line="48"/>
        <source>Gateway</source>
        <translation>Шлюз</translation>
    </message>
    <message>
        <location filename="../src/models/dhcpservermodel.cpp" line="49"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
</context>
<context>
    <name>dhcpServerProgramm</name>
    <message>
        <location filename="../src/programms/dhcpserverprogramm.cpp" line="31"/>
        <source>DHCP server</source>
        <translation>DHCP сервер</translation>
    </message>
    <message>
        <location filename="../src/programms/dhcpserverprogramm.cpp" line="72"/>
        <source>Warning</source>
        <translation>Внимание</translation>
    </message>
    <message>
        <location filename="../src/programms/dhcpserverprogramm.cpp" line="72"/>
        <source>Your DHCP server isn&apos;t configured.</source>
        <translation>DHCP сервер не настроен.</translation>
    </message>
    <message>
        <source>Wrong range</source>
        <translation type="obsolete">Ошибочный диапазон</translation>
    </message>
    <message>
        <source>You enter a wrong range of ip.</source>
        <translation type="obsolete">Вы ввели ошибочный диапазон ip.</translation>
    </message>
</context>
<context>
    <name>dhcpServerProperty</name>
    <message>
        <source>From </source>
        <translation type="obsolete">От </translation>
    </message>
    <message>
        <source>to</source>
        <translation type="obsolete">до</translation>
    </message>
    <message>
        <source>Mask</source>
        <translation type="obsolete">Маска</translation>
    </message>
    <message>
        <source>Gateway</source>
        <translation type="obsolete">Шлюз</translation>
    </message>
    <message>
        <source>Mac</source>
        <translation type="obsolete">Мас</translation>
    </message>
    <message>
        <source>Ip</source>
        <translation type="obsolete">Ip</translation>
    </message>
    <message>
        <location filename="../src/dialogs/dhcpserverproperty.cpp" line="88"/>
        <source>Wrong range</source>
        <translation>Ошибочный диапазон</translation>
    </message>
    <message>
        <location filename="../src/dialogs/dhcpserverproperty.cpp" line="88"/>
        <source>You have entered a wrong IP range.</source>
        <translation>Вы указали неверный диапазон IP адресов.</translation>
    </message>
</context>
<context>
    <name>dhspServerProperty</name>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="26"/>
        <source>DHCP server&apos;s properties</source>
        <translation>Натройки DHCP сервера</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="34"/>
        <source>Choose interface:</source>
        <translation>Укажите интерфейс: </translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="66"/>
        <source>Static:</source>
        <translation>Статические:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="98"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="109"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="132"/>
        <source>Lease term:</source>
        <translation>Срок аренды:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="154"/>
        <source> s</source>
        <translation> сек</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="122"/>
        <source>Dynamic:</source>
        <translation>Динамические: </translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="175"/>
        <location filename="../src/forms/dhcpserverproperty.ui" line="191"/>
        <location filename="../src/forms/dhcpserverproperty.ui" line="211"/>
        <location filename="../src/forms/dhcpserverproperty.ui" line="227"/>
        <source>Ip address</source>
        <translation>Ip адрес</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="178"/>
        <location filename="../src/forms/dhcpserverproperty.ui" line="194"/>
        <location filename="../src/forms/dhcpserverproperty.ui" line="214"/>
        <location filename="../src/forms/dhcpserverproperty.ui" line="230"/>
        <source>The field for ip-address.</source>
        <translation>Поле ip адреса.</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="181"/>
        <source>From:</source>
        <translation>От:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="197"/>
        <source>to:</source>
        <translation>до:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="217"/>
        <source>Mask:</source>
        <translation>Маска:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="233"/>
        <source>Gateway:</source>
        <translation>Шлюз:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="242"/>
        <source>Wating time for request from dhcp-client:</source>
        <translation>Время ожидания ответа dhcp-клиента:</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="293"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/forms/dhcpserverproperty.ui" line="304"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>dialogTemplate</name>
    <message>
        <location filename="../src/dialogs/dialogtemplate.cpp" line="28"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/dialogs/dialogtemplate.cpp" line="31"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/dialogs/dialogtemplate.cpp" line="34"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
</context>
<context>
    <name>hubChip</name>
    <message>
        <location filename="../src/chips/hubchip.cpp" line="32"/>
        <location filename="../src/chips/hubchip.cpp" line="36"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>hubDevice</name>
    <message>
        <location filename="../src/devices/hubdevice.cpp" line="33"/>
        <source>&lt;b&gt;Hub&lt;/b&gt;&lt;!--You can use HTML.--&gt;</source>
        <translation>&lt;b&gt;Концентратор&lt;/b&gt;&lt;!--Вы можете использовать HTML.--&gt;</translation>
    </message>
    <message>
        <location filename="../src/devices/hubdevice.h" line="40"/>
        <source>Hub</source>
        <translation>Концентратор</translation>
    </message>
</context>
<context>
    <name>hubProperty</name>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="33"/>
        <source>Number of ports: </source>
        <translation>Количество портов:</translation>
    </message>
    <message>
        <source>Manage via SNMP: </source>
        <translation type="obsolete">Управляемый через SNMP:</translation>
    </message>
    <message>
        <source>Properies</source>
        <translation type="obsolete">Настройки</translation>
    </message>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="30"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="44"/>
        <source>Mac-address: </source>
        <translation>Мас-адрес: </translation>
    </message>
    <message>
        <source>Ip-address: </source>
        <translation type="obsolete">Ip-адрес: </translation>
    </message>
    <message>
        <source>Mask: </source>
        <translation type="obsolete">Маска:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="58"/>
        <source>Reset statistics</source>
        <translation>Сбросить статистику</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete">Описание:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="76"/>
        <source>Number of collisions: %1</source>
        <translation>Количество коллизий: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="93"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/hubproperty.cpp" line="94"/>
        <source>First, remove the cables!</source>
        <translation>Сначала отсоедините кабеля от устройства!</translation>
    </message>
</context>
<context>
    <name>installDialog</name>
    <message>
        <location filename="../src/forms/installdialog.ui" line="39"/>
        <source>RIP</source>
        <translation></translation>
    </message>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Настройки</translation>
    </message>
    <message>
        <source>Programms</source>
        <translation type="obsolete">Программы</translation>
    </message>
    <message>
        <location filename="../src/forms/installdialog.ui" line="20"/>
        <source>Programs</source>
        <translation>Программы</translation>
    </message>
    <message>
        <location filename="../src/forms/installdialog.ui" line="28"/>
        <source>Available programs: </source>
        <translation>Доступные программы:</translation>
    </message>
    <message>
        <location filename="../src/forms/installdialog.ui" line="44"/>
        <source>DHCP client</source>
        <translation>DHCP клиент</translation>
    </message>
    <message>
        <location filename="../src/forms/installdialog.ui" line="52"/>
        <source>DHCP server</source>
        <translation>DHCP сервер</translation>
    </message>
    <message>
        <location filename="../src/forms/installdialog.ui" line="80"/>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="../src/forms/installdialog.ui" line="91"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/dialogs/installdialog.cpp" line="42"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/installdialog.cpp" line="42"/>
        <source>Program already installed.</source>
        <translation>Программа уже установлена.</translation>
    </message>
</context>
<context>
    <name>interfaceDialog</name>
    <message>
        <source>Add adapter</source>
        <translation type="obsolete">Добавить адаптер</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="obsolete">Добавить</translation>
    </message>
    <message>
        <source>Add netcard</source>
        <translation type="obsolete">Добавить сетевую карту</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Отмена</translation>
    </message>
    <message>
        <source>Speed: 10/100 Mbit/s</source>
        <translation type="obsolete">Скорость: 10/100 Мбит/с</translation>
    </message>
    <message>
        <source>Speed: 10/100/1000 Mbit/s</source>
        <translation type="obsolete">Скорость: 10/100/1000 Мбит/с</translation>
    </message>
    <message utf8="true">
        <source>Speed: 10/100 Мбит/с</source>
        <translation type="obsolete">Скорость : 10/100 Мбит/с</translation>
    </message>
</context>
<context>
    <name>logDialog</name>
    <message>
        <source>Routing has been &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="obsolete">Маршрутизация была &lt;b&gt;включена&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Routing has been &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="obsolete">Маршрутизация была &lt;b&gt;выключена&lt;/b&gt;</translation>
    </message>
    <message>
        <source>send </source>
        <translation type="obsolete">посылаю</translation>
    </message>
    <message>
        <source>receive </source>
        <translation type="obsolete">получаю</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="66"/>
        <source>sent </source>
        <translation>послал </translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="66"/>
        <source>received </source>
        <translation>получил </translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="76"/>
        <location filename="../src/dialogs/logdialog.cpp" line="143"/>
        <source> Type: </source>
        <translation> Тип: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="96"/>
        <source>DHCP Message, Type: %1</source>
        <translation>DHCP сообщение, тип: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="97"/>
        <source>Xid: %1, Yiaddr: %2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="98"/>
        <source>Siaddr: %1, Chaddr: %2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="112"/>
        <source>ISN %1, ACK %2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="116"/>
        <source>flags: No flags</source>
        <translation>флаги: No flags</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="118"/>
        <source>flags: Ack</source>
        <translation>флаги: ACK</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="119"/>
        <source>flags: SYN</source>
        <translation>флаги: SYN</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="120"/>
        <source>flags: SYN, ACK</source>
        <translation>флаги: SYN, ACK</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="121"/>
        <source>flags: Fin</source>
        <translation>флаги: FIN</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="133"/>
        <source>request</source>
        <translation>запрос</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="134"/>
        <source>response</source>
        <translation>ответ</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="137"/>
        <source> search </source>
        <translation> ищет </translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="141"/>
        <source> found </source>
        <translation> нашел </translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="148"/>
        <source>ARP-%1:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="151"/>
        <source>sender IP address: %1</source>
        <translation>IP адрес отправителя: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="154"/>
        <source>sender MAC address: %1</source>
        <translation>MAC адрес отправителя: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="157"/>
        <source>target IP address: %1</source>
        <translation>IP адрес назначения: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/logdialog.cpp" line="160"/>
        <source>target MAC address: %1</source>
        <translation>MAC адрес назначения: %1</translation>
    </message>
    <message>
        <source>Count: %1</source>
        <translation type="obsolete">Количество: %1</translation>
    </message>
    <message>
        <source>ip-packet: &lt;b&gt;</source>
        <translation type="obsolete">ip-пакет: &lt;b&gt;</translation>
    </message>
    <message>
        <source>arp-request: &lt;b&gt;</source>
        <translation type="obsolete">arp-запрос: &lt;b&gt;</translation>
    </message>
    <message>
        <source>search &lt;b&gt;</source>
        <translation type="obsolete">ищет &lt;b&gt;</translation>
    </message>
    <message>
        <source>arp-response: &lt;b&gt;</source>
        <translation type="obsolete">arp-ответ &lt;b&gt;</translation>
    </message>
    <message>
        <source>found &lt;b&gt;</source>
        <translation type="obsolete">нашел &lt;b&gt;</translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Show mac</source>
        <translation type="obsolete">Показывать mac-адреса</translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="49"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="73"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="78"/>
        <source>Arp</source>
        <translation>Arp</translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="83"/>
        <source>TCP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="88"/>
        <source>UDP</source>
        <translation>UDP</translation>
    </message>
    <message>
        <source>Ip</source>
        <translation type="obsolete">Ip</translation>
    </message>
    <message>
        <location filename="../src/forms/logdialog.ui" line="96"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
</context>
<context>
    <name>myCanvas</name>
    <message>
        <location filename="../src/mycanvas.cpp" line="185"/>
        <location filename="../src/mycanvas.cpp" line="240"/>
        <source>Opening file for reading is impossible</source>
        <translation>Невозможно открыть файл для чтения</translation>
    </message>
    <message>
        <location filename="../src/mycanvas.cpp" line="194"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mycanvas.cpp" line="194"/>
        <source>Outdated version of the file, file can&apos;t be opened</source>
        <translation>Устаревшая версия файла сохранения, файл не может быть открыт</translation>
    </message>
    <message>
        <location filename="../src/mycanvas.cpp" line="230"/>
        <location filename="../src/mycanvas.cpp" line="249"/>
        <source>Scene opened from %1</source>
        <translation>Сцена открыта из файла %1</translation>
    </message>
    <message>
        <location filename="../src/mycanvas.cpp" line="284"/>
        <location filename="../src/mycanvas.cpp" line="300"/>
        <source>Scene saved in %1</source>
        <translation>Сцена сохранена в файл %1</translation>
    </message>
    <message>
        <location filename="../src/mycanvas.cpp" line="261"/>
        <location filename="../src/mycanvas.cpp" line="292"/>
        <source>Opening file for writing is impossible %1</source>
        <translation>Невозможно открыть файл для записи %1</translation>
    </message>
    <message>
        <source>Opening file for writing is impossible</source>
        <translation type="obsolete">Невозможно открыть файл для записи</translation>
    </message>
    <message>
        <source>Opening file for writeng is impossible</source>
        <translation type="obsolete">Невозможно открыть файл для записи</translation>
    </message>
    <message>
        <source>The device can&apos;t transmit data!</source>
        <translation type="obsolete">Устройство не может отправлять данные!</translation>
    </message>
    <message>
        <source>The outdated version of the file, file can&apos;t be opened</source>
        <translation type="obsolete">Устаревшая версия файла сохранения. Файл не может быть открыт</translation>
    </message>
    <message>
        <location filename="../src/mycanvas.h" line="64"/>
        <source>Commentary</source>
        <translation>Комментарий</translation>
    </message>
</context>
<context>
    <name>programmDialog</name>
    <message>
        <source>Programms</source>
        <translation type="obsolete">Программы</translation>
    </message>
    <message>
        <source>Installed programms</source>
        <translation type="obsolete">Установленные программы</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="20"/>
        <source>Programs</source>
        <translation>Программы</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="30"/>
        <source>Installed programs</source>
        <translation>Установленные программы</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="60"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="74"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="88"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="112"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/forms/programmdialog.ui" line="123"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>ripProgramm</name>
    <message>
        <location filename="../src/programms/ripprogramm.cpp" line="34"/>
        <source>RIP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ripProperty</name>
    <message>
        <source>Rip programm property</source>
        <translation type="obsolete">Настройки RIP</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="14"/>
        <source>Rip program property</source>
        <translation>Настройки RIP</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="22"/>
        <source>Split horizon:</source>
        <translation>Расщипление горизонтов:</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="36"/>
        <source>Disable</source>
        <translation>Выключено</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="41"/>
        <source>Enable</source>
        <translation>Включено</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="46"/>
        <source>With poison reverse</source>
        <translation>С отравлением обратных путей</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="56"/>
        <source> Turn On/Off triggered updates</source>
        <translation>Включить/выключить триггерное обновление</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="91"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/forms/ripproperty.ui" line="102"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>routeEditor</name>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="35"/>
        <source>Routing table</source>
        <translation>Таблица маршртизации</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="46"/>
        <source>Destination: </source>
        <translation>Адрес назначения:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="48"/>
        <source>Mask: </source>
        <translation>Маска:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="50"/>
        <source>Gateway: </source>
        <translation>Шлюз: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="53"/>
        <source>Interface: </source>
        <translation>Интерфейс: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="67"/>
        <source>Metric: </source>
        <translation>Метрика: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="77"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="81"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routeeditor.cpp" line="87"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>routeModel</name>
    <message>
        <location filename="../src/models/routemodel.cpp" line="51"/>
        <source>Destination</source>
        <translation>Адрес назначения</translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="52"/>
        <source>Mask</source>
        <translation>Маска</translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="53"/>
        <source>Gateway</source>
        <translation>Шлюз</translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="54"/>
        <source>Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="55"/>
        <source>Metric</source>
        <translation>Метрика</translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="56"/>
        <source>Source</source>
        <translation>Источник</translation>
    </message>
    <message>
        <location filename="../src/models/routemodel.cpp" line="198"/>
        <source>Connected</source>
        <translation>Подключена</translation>
    </message>
</context>
<context>
    <name>routerDevice</name>
    <message>
        <location filename="../src/devices/routerdevice.cpp" line="33"/>
        <location filename="../src/devices/routerdevice.cpp" line="63"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/devices/routerdevice.cpp" line="34"/>
        <source>&lt;b&gt;Router&lt;/b&gt;&lt;!--You can use HTML.--&gt;</source>
        <translation>&lt;b&gt;Маршрутизатор&lt;/b&gt;&lt;!--Вы можете использовать HTML.--&gt;</translation>
    </message>
    <message>
        <location filename="../src/devices/routerdevice.cpp" line="68"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/devices/routerdevice.cpp" line="68"/>
        <source>To change the number of ports, disconnect all cables!</source>
        <translation>Для изменения количества портов, сначала отключите провода!</translation>
    </message>
    <message>
        <location filename="../src/devices/routerdevice.h" line="34"/>
        <source>Router</source>
        <translation>Маршрутизатор</translation>
    </message>
</context>
<context>
    <name>routerProperty</name>
    <message>
        <source>Properies</source>
        <translation type="obsolete">Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routerproperty.cpp" line="32"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routerproperty.cpp" line="35"/>
        <source>Number of ports: </source>
        <translation>Количество портов:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/routerproperty.cpp" line="43"/>
        <source>Enable routing</source>
        <translation>Включить маршрутизацию</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete">Описание:</translation>
    </message>
</context>
<context>
    <name>sendDialog</name>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="79"/>
        <source> KB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="39"/>
        <source>Sending</source>
        <translation>Отправка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="75"/>
        <source>Size KB</source>
        <translation>Размер в килобайтах</translation>
    </message>
    <message>
        <source>Broadcast</source>
        <translation type="obsolete">Широковещательный</translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="86"/>
        <source>Next</source>
        <translation>Далее</translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="87"/>
        <source>Choose protocol:</source>
        <translation>Выберите протокол:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="89"/>
        <source>UDP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="91"/>
        <source>TCP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="113"/>
        <source>Select the network card receiver</source>
        <translation>Укажите интерфейс приемника</translation>
    </message>
    <message>
        <location filename="../src/dialogs/senddialog.cpp" line="114"/>
        <source>Send</source>
        <translation>Отправка</translation>
    </message>
</context>
<context>
    <name>settingDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Настройки</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="57"/>
        <source>General</source>
        <translation>Главные</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="72"/>
        <source>Computer</source>
        <translation>Компьютер</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="84"/>
        <source>Hub</source>
        <translation>Концентратор</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="96"/>
        <source>Switch</source>
        <translation>Коммутатор</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="108"/>
        <source>Router</source>
        <translation>Маршрутизатор</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="664"/>
        <source>Lifetime arp-entries: </source>
        <translation>Время жизни arp-записей:</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="559"/>
        <location filename="../src/forms/settingdialog.ui" line="689"/>
        <location filename="../src/forms/settingdialog.ui" line="719"/>
        <location filename="../src/forms/settingdialog.ui" line="807"/>
        <source> s</source>
        <translation> сек</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="120"/>
        <source>Netcard</source>
        <translation>Интерфейсы</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="132"/>
        <source>Tcp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="231"/>
        <source>Animation speed:</source>
        <translation>Скорость анимации: </translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="166"/>
        <source>Language: </source>
        <translation>Язык приложения: </translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="180"/>
        <source>English</source>
        <translation>Английский</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="185"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="190"/>
        <source>Brazillian Portuguese</source>
        <translation>Бразильский португальский</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="195"/>
        <source>Spanish</source>
        <translation>Испанский</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="157"/>
        <source>Turn on/off OpenGL</source>
        <translation>Включить/Выключить OpenGL</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="207"/>
        <source>Autosave</source>
        <translation>Автосохранение</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="284"/>
        <source>Interval: </source>
        <translation>Интервал:</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="344"/>
        <source>Nubmer of interfaces by default:</source>
        <translation>Количество интерфейсов по умолчанию: </translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="358"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="363"/>
        <location filename="../src/forms/settingdialog.ui" line="610"/>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="368"/>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="373"/>
        <location filename="../src/forms/settingdialog.ui" line="426"/>
        <location filename="../src/forms/settingdialog.ui" line="499"/>
        <location filename="../src/forms/settingdialog.ui" line="615"/>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="378"/>
        <location filename="../src/forms/settingdialog.ui" line="431"/>
        <location filename="../src/forms/settingdialog.ui" line="504"/>
        <location filename="../src/forms/settingdialog.ui" line="620"/>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="383"/>
        <location filename="../src/forms/settingdialog.ui" line="436"/>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="412"/>
        <source>Number of ports by default</source>
        <translation>Количество портов по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="441"/>
        <location filename="../src/forms/settingdialog.ui" line="509"/>
        <location filename="../src/forms/settingdialog.ui" line="630"/>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="446"/>
        <location filename="../src/forms/settingdialog.ui" line="514"/>
        <source>12</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="451"/>
        <location filename="../src/forms/settingdialog.ui" line="524"/>
        <source>24</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="456"/>
        <location filename="../src/forms/settingdialog.ui" line="534"/>
        <source>48</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="485"/>
        <location filename="../src/forms/settingdialog.ui" line="596"/>
        <source>Number of ports by default: </source>
        <translation>Количество портов по умолчанию: </translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="519"/>
        <source>16</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="529"/>
        <source>32</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="546"/>
        <source>Switching table&apos;s records lifetime:</source>
        <translation>Время жизни записей таблицы коммутации:</translation>
    </message>
    <message>
        <source>Lifetime records of table switching</source>
        <translation type="obsolete">Время жизни записей таблицы коммутации</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="625"/>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="635"/>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="706"/>
        <source>Expectation time for arp-responce</source>
        <translation>Время ожидания arp-ответа</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="753"/>
        <source>Number of repeat sendings:</source>
        <translation>Количество повторных отправок:</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="782"/>
        <source>Waiting confirmation time:</source>
        <translation>Время ожидания подтверждения соединения:</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="857"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="871"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="882"/>
        <source>Ok</source>
        <translation>Ок</translation>
    </message>
    <message>
        <location filename="../src/forms/settingdialog.ui" line="899"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>smartDevice</name>
    <message>
        <location filename="../src/devices/smartdevice.cpp" line="497"/>
        <source>eth%1</source>
        <translation></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Ошибка</translation>
    </message>
    <message>
        <source>Such a program already installed.</source>
        <translation type="obsolete">Такая программа уже установлена.</translation>
    </message>
    <message>
        <location filename="../src/devices/smartdevice.h" line="49"/>
        <source>Routing Table</source>
        <translation>Таблица маршрутизации</translation>
    </message>
</context>
<context>
    <name>staticsDialog</name>
    <message>
        <location filename="../src/forms/staticsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Статистика</translation>
    </message>
    <message>
        <location filename="../src/forms/staticsdialog.ui" line="28"/>
        <source>Devices:</source>
        <translation>Устройства:</translation>
    </message>
    <message>
        <location filename="../src/forms/staticsdialog.ui" line="43"/>
        <location filename="../src/forms/staticsdialog.ui" line="72"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/staticsdialog.ui" line="63"/>
        <source>Traffic:</source>
        <translation>Трафик:</translation>
    </message>
    <message>
        <location filename="../src/forms/staticsdialog.ui" line="108"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>statisticsScene</name>
    <message>
        <location filename="../src/tools/statisticsscene.cpp" line="44"/>
        <source>Number of devices: %1
</source>
        <translation>Количество устройств: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statisticsscene.cpp" line="45"/>
        <source>Number of computers: %1
</source>
        <translation>Количество компьютеров: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statisticsscene.cpp" line="46"/>
        <source>Number of hubs: %1
</source>
        <translation>Количество концентраторов: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statisticsscene.cpp" line="47"/>
        <source>Number of switchs: %1
</source>
        <translation>Количество коммутаторов: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statisticsscene.cpp" line="48"/>
        <source>Number of routers: %1
</source>
        <translation>Количество роутеров: %1
</translation>
    </message>
    <message>
        <location filename="../src/tools/statisticsscene.cpp" line="49"/>
        <source>Number of cables: %1
</source>
        <translation>Количество проводов: %1
</translation>
    </message>
    <message>
        <source>Send packets: %1
</source>
        <translation type="obsolete">Отправлено пакетов: %1
</translation>
    </message>
</context>
<context>
    <name>switchChip</name>
    <message>
        <location filename="../src/chips/switchchip.cpp" line="47"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>switchDevice</name>
    <message>
        <source>Table switching</source>
        <translation type="obsolete">Таблица коммутации</translation>
    </message>
    <message>
        <location filename="../src/devices/switchdevice.cpp" line="35"/>
        <source>&lt;b&gt;Switch&lt;/b&gt;&lt;!--You can use HTML.--&gt;</source>
        <translation>&lt;b&gt;Коммутатор&lt;/b&gt;&lt;!--Вы можете использовать HTML.--&gt;</translation>
    </message>
    <message>
        <location filename="../src/devices/switchdevice.h" line="52"/>
        <source>Switch</source>
        <translation>Коммутатор</translation>
    </message>
    <message>
        <location filename="../src/devices/switchdevice.h" line="53"/>
        <source>Switching table</source>
        <translation>Таблица коммутации</translation>
    </message>
</context>
<context>
    <name>switchModel</name>
    <message>
        <location filename="../src/models/switchmodel.cpp" line="52"/>
        <source>Mac-address</source>
        <translation>Мас-адрес</translation>
    </message>
    <message>
        <location filename="../src/models/switchmodel.cpp" line="53"/>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
    <message>
        <location filename="../src/models/switchmodel.cpp" line="54"/>
        <source>Record type</source>
        <translation>Тип записи</translation>
    </message>
    <message>
        <location filename="../src/models/switchmodel.cpp" line="55"/>
        <source>TTL</source>
        <translation>Время жизни</translation>
    </message>
    <message>
        <location filename="../src/models/switchmodel.cpp" line="68"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>switchProperty</name>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="34"/>
        <source>Number of ports: </source>
        <translation>Количество портов:</translation>
    </message>
    <message>
        <source>Managed via SNMP: </source>
        <translation type="obsolete">Управляемый через SNMP:</translation>
    </message>
    <message>
        <source>Properies</source>
        <translation type="obsolete">Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="31"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="44"/>
        <source>Manageable</source>
        <translation>Управляемый</translation>
    </message>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="49"/>
        <source>Mac-address: </source>
        <translation>Мас-адрес: </translation>
    </message>
    <message>
        <source>Ip-address: </source>
        <translation type="obsolete">Ip-адрес: </translation>
    </message>
    <message>
        <source>Mask: </source>
        <translation type="obsolete">Маска:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="60"/>
        <source>Reset statistics</source>
        <translation>Сбросить статистику</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete">Описание:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="96"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/switchproperty.cpp" line="97"/>
        <source>First, remove the cables!</source>
        <translation>Сначала отсоедините кабеля от устройства!</translation>
    </message>
</context>
<context>
    <name>tableArp</name>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="37"/>
        <source>Arp table</source>
        <translation>Arp таблица</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="46"/>
        <source>Mac-address</source>
        <translation>Мас-адрес</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="46"/>
        <source>Ip-address</source>
        <translation>Ip-адрес</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="46"/>
        <source>Record type</source>
        <translation>Тип записи</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="46"/>
        <source>Netcard name</source>
        <translation>Имя адаптера</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="47"/>
        <source>TTL</source>
        <translation>Время жизни</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="52"/>
        <source>Mac-address: </source>
        <translation>Мас-адрес: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="59"/>
        <source>Ip-address: </source>
        <translation>Ip-адрес: </translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="61"/>
        <source>Netcard</source>
        <translation>Адапер</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="68"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="70"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/tablearp.cpp" line="73"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>tableSwitch</name>
    <message>
        <location filename="../src/dialogs/tableswitch.cpp" line="34"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
    <message>
        <source>Table switching</source>
        <translation type="obsolete">Таблица коммутации</translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="14"/>
        <source>Switching table</source>
        <translation>Таблица коммутации</translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="44"/>
        <source>Mac-address: </source>
        <translation>Мас-адрес: </translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="63"/>
        <source>HH:HH:HH:HH:HH:HH;_</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="66"/>
        <source>00:00:00:00:00:00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="73"/>
        <source>Port: </source>
        <translation>Порт: </translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="94"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="108"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/forms/tableswitch.ui" line="132"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>tcpSocket</name>
    <message>
        <location filename="../src/tools/tcpsocket.cpp" line="187"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/tools/tcpsocket.cpp" line="187"/>
        <source>TCP: Data transmition error</source>
        <translation>TCP: Ошибка передачи данных</translation>
    </message>
</context>
<context>
    <name>testDialog</name>
    <message>
        <location filename="../src/dialogs/testdialog.cpp" line="105"/>
        <source>Script finished correctly</source>
        <translation>Скрипт завершился корректно</translation>
    </message>
    <message>
        <location filename="../src/dialogs/testdialog.cpp" line="108"/>
        <source>Script not correctly finished</source>
        <translation>Скрипт завершился не корректно</translation>
    </message>
    <message>
        <location filename="../src/dialogs/testdialog.cpp" line="147"/>
        <source>Choose a directory with scripts</source>
        <translation>Выберите каталог со скриптами</translation>
    </message>
    <message>
        <source>Script finished is not correctly</source>
        <translation type="obsolete">Скрипт завершился не корректно</translation>
    </message>
    <message>
        <location filename="../src/forms/testdialog.ui" line="14"/>
        <source>Scripts</source>
        <translation>Скрипты</translation>
    </message>
    <message>
        <location filename="../src/forms/testdialog.ui" line="34"/>
        <source>Start</source>
        <translation>Запустить</translation>
    </message>
    <message>
        <location filename="../src/forms/testdialog.ui" line="41"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/forms/testdialog.ui" line="48"/>
        <source>Set path</source>
        <translation>Задать путь</translation>
    </message>
    <message>
        <location filename="../src/forms/testdialog.ui" line="55"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../src/dialogs/testdialog.cpp" line="156"/>
        <location filename="../src/forms/testdialog.ui" line="79"/>
        <source>Click start</source>
        <translation>Нажмите старт</translation>
    </message>
</context>
<context>
    <name>virtualNetwork</name>
    <message>
        <location filename="../src/chips/switchchip.cpp" line="95"/>
        <location filename="../src/chips/switchchip.cpp" line="102"/>
        <location filename="../src/chips/switchchip.cpp" line="125"/>
        <source>LAN%1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>virtualNetworkDialog</name>
    <message>
        <location filename="../src/forms/virtualnetworkdialog.ui" line="13"/>
        <source>Dialog</source>
        <translation>Настройки</translation>
    </message>
</context>
</TS>
